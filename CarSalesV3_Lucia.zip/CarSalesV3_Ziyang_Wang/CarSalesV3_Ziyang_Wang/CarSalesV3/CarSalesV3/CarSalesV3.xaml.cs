﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Xml.Linq;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

/* Ziyang Wang
 * 20/June/2023
 */

namespace CarSalesV3
{
    /// <summary>
    /// This class has 4 event handlers: saveButtonClick, resetButtonClick, summaryButtonClick AND insuranceToggleSwitch_Toggled.
    /// saveButtonClick validate customer details, disables customer details, set focus to vehiclePrice.
    /// resetButtonClick clears all inputs and controls, enable customer details, sets focus to customer name.
    /// summaryButtonClick try/catch vehiclePrice and tradeIn as double datatype, validates vehiclePrice and tradeIn values. 
    /// summaryButtonClick then calculate and display the vehicleWarranty, optionalExtras, insuranceCost, sub Amount, GST Amount and final Amount of the vehicle cost.
    /// summaryButtonClick will also display a summarying message in the summary TextBlock.
    /// insuranceToggleSwitch_Toggled will enable/disbale raido buttons based on its toggle status.
    /// This class also contains 3 methods: calcVehicleWarranty, calcOptionalExtras and calcAccidentInsurance.
    /// They calculate and return 3 values respectively: warranty cost, optional extra total cost and insurance cost.
    /// This class also has: generateRandomPhoneNumber method to generate a 10-number string starting with 04;
    /// shuffleArray method to shuffle the order of items in the array and return the shuffled array;
    /// Page_Load event handler where 3 class arrays are populated;
    /// displayCustomerButton_Click method displays all customer names and corresponding phone numbers in summaryTextBlock;
    /// searchNameButton_Click method performs sequential search through customerName array against user input for a match;
    /// deleteNameButton_Click method sequential search and delete target items from customerName & customerPhone array if found a match;
    /// displayMakeButton_Click method displays vehicleMakes array sorted in alphabetical order in summaryTextBlock;
    /// searchMakeButton_Click method binary search whether a vehicle make exists in the array and output corresponding message to user;
    /// arrayStringBinarySearch method performs a binary search on a string array to determine whether a given item exists;
    /// insertMakeButton_Click method binary search thorugh array and insert user input to it if not found, otherwise produce an error message.
    /// </summary>
    public sealed partial class CarSalesV3 : Page
    {
        // Define class-level constants
        private const double GST_RATE = 0.1;
        private const double WARRANTY_RATE_1 = 0;
        private const double WARRANTY_RATE_2 = 0.05;
        private const double WARRANTY_RATE_3 = 0.1;
        private const double WARRANTY_RATE_5 = 0.2;
        private const double WINDOW_TINT = 150;
        private const double DUCO_PROTECT = 180;
        private const double FLOOR_MAT = 320;
        private const double DELUXE_SOUND = 350;
        private const double INSURANCE_YOUNG_RATE = 0.2;
        private const double INSURANCE_OLD_RATE = 0.1;

        // Define arrays
        string[] customerName = new string[10];
        string[] customerPhone = new string[10];
        string[] vehicleMakes = new string[8];

        public CarSalesV3()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// A method to generate random numbers starting with "04"
        /// </summary>
        /// <returns> concatenated string starting with "04", followed by a string of 8 random numbers </returns>
        private string generateRandomPhoneNumber()
        {
            // Define a random object
            Random random = new Random();
            // Generate a random phone number starting with "04"
            return "04" + random.Next(10000000, 99999999).ToString();
        }

        /// <summary>
        /// A method to shuffle the array.
        /// </summary>
        /// <param name="array"></param>
        static void shuffleArray(string[] array)
        {
            // Define a random object to generate random number
            Random random = new Random();

            // for loop to shuffle the order of index items in the array
            for (int i = 0; i < (array.Length - 1); i++)
            {
                // Next is used to prevent the loop go over the length of the array
                int r = i + random.Next(array.Length - i);
                string temp = array[r];
                array[r] = array[i];
                array[i] = temp;
            }
        }

        /// <summary>
        /// Page loaded event handler that populates data into 3 class level arrays
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            // Define an array to contain random names
            string[] randomNames = { "John", "Libby", "Mike", "Emily", "David", "Sarah", "Kyle", "Amy", "Chris", "Laura" };
            // Call shuffleArray method to shuffle this array
            shuffleArray(randomNames);

            // Use for loop to populate data from previous methods
            for (int index = 0; index < customerName.Length; index++)
            {
                // populate data from shuffled randomName array
                customerName[index] = randomNames[index];
                // populate data using generateRandomPhoneNumber method
                customerPhone[index] = generateRandomPhoneNumber();
            }

            // Populate vehicleMakes array
            vehicleMakes = new string[] { "Toyota", "Holden", "Mitsubishi", "Ford", "BMW", "Mazda", "Volkswagen", "Mini" };
        }

        /// <summary>
        /// Handles the button click event for the Save button.
        /// It validates customer details, disables customer details, and set focus to vehiclePrice.
        /// </summary>
        private async void saveButtonClick(object sender, RoutedEventArgs e)
        {
            // Validate that customerNameTextBox is not left blank
            if (string.IsNullOrWhiteSpace(customerNameTextBox.Text))
            {
                // if the customerNameTextBox is empty or whitespace-only, display an error message for user
                var invalidMessage = new MessageDialog("Error! Please enter a customer name. Customer name cannot be left blank.");
                await invalidMessage.ShowAsync();
                // set focus to customerNameTextBox
                customerNameTextBox.Focus(FocusState.Programmatic);
                // return to caller
                return;
            }

            // Validate that phoneTextBox is not left blank
            if (string.IsNullOrWhiteSpace(phoneTextBox.Text))
            {
                // if the phoneTextBox is empty or whitespace-only, display an error message for user
                var invalidMessage = new MessageDialog("Error! Please enter a phone number. Phone number cannot be left blank.");
                await invalidMessage.ShowAsync();
                // set focus to phoneTextBox
                phoneTextBox.Focus(FocusState.Programmatic);
                // return to caller
                return;
            }

            customerNameTextBox.IsEnabled = false;
            phoneTextBox.IsEnabled = false;

            vehiclePriceTextBox.Focus(FocusState.Programmatic);
        }

        /// <summary>
        /// Handles the button click event for the Reset button.
        /// It clears all inputs and controls, enable customer details, sets focus to customer name.
        /// </summary>
        private void resetButtonClick(object sender, RoutedEventArgs e)
        {
            // Clear all TextBox and summary TextBlock
            customerNameTextBox.Text = "";
            phoneTextBox.Text = "";
            vehiclePriceTextBox.Text = "";
            tradeInTextBox.Text = "";
            subAmountTextBox.Text = "";
            gstAmountTextBox.Text = "";
            finalAmountTextBox.Text = "";

            summaryTextBlock.Text = "";

            // Reset control of all combobox, checkbox, radiobutton and toggle swtich
            warrantyComboBox.SelectedIndex = 0;

            windowCheckBox.IsChecked = false;
            ducoCheckBox.IsChecked = false;
            floorCheckBox.IsChecked = false;
            soundCheckBox.IsChecked = false;

            insuranceToggleSwitch.IsOn = false;
            youngRadioButton.IsChecked = false;
            youngRadioButton.IsEnabled = false;
            oldRadioButton.IsChecked = false;
            oldRadioButton.IsEnabled = false;

            // Enbale TextBox of customer detail
            customerNameTextBox.IsEnabled = true;
            phoneTextBox.IsEnabled = true;

            // Set focus to cutomer name TextBox
            customerNameTextBox.Focus(FocusState.Programmatic);
        }

        /// <summary>
        /// Handles the button click event for the Summary button.
        /// It try/catch vehiclePrice and tradeIn as double datatype, validates vehiclePrice and tradeIn values. 
        /// It then calculate and display the vehicleWarranty, optionalExtras, insuranceCost, sub Amount, GST Amount and final Amount of the vehicle cost.
        /// It also displays a summarying message in the summary TextBlock.
        /// </summary>
        private async void summaryButtonClick(object sender, RoutedEventArgs e)
        {
            // Define local variables
            double vehiclePrice;
            double tradeIn;
            double subAmount;
            double gstAmount;
            double finalAmount;
            double vehicleWarranty;
            double optionalExtras;
            double insuranceCost;

            // try to parse the input from vehiclePriceTextBox as a double datatype and assigns it to the vehiclePrice variable.
            try
            {
                vehiclePrice = double.Parse(vehiclePriceTextBox.Text);
            }

            // catch the exception while the input datatype of vehiclePrice does not match double datatype
            catch (Exception theException)
            {
                // if exception is caught during parsing process, display an error message for user
                var dialogMessage = new MessageDialog("Error! Please enter a valid number for vehicle price. " + theException.Message);
                await dialogMessage.ShowAsync();
                // set focus to vehiclePriceTextBox
                vehiclePriceTextBox.Focus(FocusState.Programmatic);
                // all content in it is selected for easier change
                vehiclePriceTextBox.SelectAll();
                // return to caller
                return;
            }

            // try to validate and parse tradeInTextBox input as a double datatype and assigns it to the tradeIn variable.
            try
            {
                // Validate the value of tradeIn when tradeInTextBox is empty
                if (string.IsNullOrEmpty(tradeInTextBox.Text))
                {
                    // if the tradeInTextBox is empty, set tradeIn variable to 0
                    tradeIn = 0;
                    // also set tradeInTextBox to 0 for visualisation
                    tradeInTextBox.Text = "0";
                    // return to caller
                    return;
                }
                // When tradeInTextBox is not empty, parse the input from tradeInTextBox as a double datatype and assigns it to the tradeIn variable.
                tradeIn = double.Parse(tradeInTextBox.Text);
            }

            // catch the exception while the input datatype of tradeIn does not match double datatype
            catch (Exception theException)
            {
                // if exception is caught during parsing process, display an error message for user
                var dialogMessage = new MessageDialog("Error! Please enter a valid number for trade-in value. " + theException.Message);
                await dialogMessage.ShowAsync();
                // set focus to tradeInTextBox
                tradeInTextBox.Focus(FocusState.Programmatic);
                // all content in it is selected for easier change
                tradeInTextBox.SelectAll();
                // return to caller
                return;
            }

            // Validate that vehiclePrice greater than 0
            if (vehiclePrice <= 0)
            {
                // If vehiclePrice is less than or equals to 0, then display an error message for user
                var invalidMessage = new MessageDialog("Error! Please enter a valid vehicle price. Vehicle price must be greater than 0.");
                await invalidMessage.ShowAsync();
                // set focus to vehiclePriceTextBox
                vehiclePriceTextBox.Focus(FocusState.Programmatic);
                // all content in it is selected for easier change
                vehiclePriceTextBox.SelectAll();
                // return to caller
                return;
            }

            // Validate that tradeIn is not negative
            if (tradeIn < 0)
            {
                // If tradeIn is less than 0, then display an error message for user
                var invalidMessage = new MessageDialog("Error! Please enter a valid trade-in value. Trade-in value must not be negative.");
                await invalidMessage.ShowAsync();
                // set focus to tradeInTextBox
                tradeInTextBox.Focus(FocusState.Programmatic);
                // all content in it is selected for easier change
                tradeInTextBox.SelectAll();
                // return to caller
                return;
            }

            // Validate that vehiclePrice is greater than tradeIn
            if (vehiclePrice <= tradeIn)
            {
                // If vehiclePrice is less than or equals to tradeIn, then display an error message for user
                var invalidMessage = new MessageDialog("Error! Please enter valid vehicle price and trade-in values. Vehicle price must be greater than trade-in value.");
                await invalidMessage.ShowAsync();
                // set focus to vehiclePriceTextBox
                vehiclePriceTextBox.Focus(FocusState.Programmatic);
                // select all content in vehiclePriceTextBox is selected for easier change
                vehiclePriceTextBox.SelectAll();
                // return to caller
                return;
            }

            // Calculate the vehicleWarranty on vehiclePrice
            vehicleWarranty = calcVehicleWarranty(vehiclePrice);

            // Calculate the optionalExtras
            optionalExtras = calcOptionalExtras();

            // Calculate the insuranceCost on vehiclePrice and optionalExtras
            insuranceCost = calcAccidentInsurance(vehiclePrice, optionalExtras);

            // Calculate and display the subAmount
            subAmount = vehiclePrice + vehicleWarranty + optionalExtras + insuranceCost - tradeIn;
            subAmountTextBox.Text = subAmount.ToString("C");

            // Calculate and display the gstAmount
            gstAmount = subAmount * GST_RATE;
            gstAmountTextBox.Text = gstAmount.ToString("C");

            // Calculate and display the finalAmount
            finalAmount = subAmount + gstAmount;
            finalAmountTextBox.Text = finalAmount.ToString("C");

            // Output summary message to summaryTextBlock
            summaryTextBlock.Text = "Current Purchase Details:\n\n" + "Customer Name: " + customerNameTextBox.Text + "\n" + "Phone Number: " + phoneTextBox.Text + "\n" + "Vehicle Cost: " + vehiclePrice.ToString("C") + "\n" + "Trade-In Amount: " + tradeIn.ToString("C") + "\n" + "Warranty Cost: " + vehicleWarranty.ToString("C") + "\n" + "Optional Extras Cost: " + optionalExtras.ToString("C") + "\n" + "Insurance Cost: " + insuranceCost.ToString("C") + "\n" + "Final Amount: " + finalAmount.ToString("C");
        }

        /// <summary>
        /// calculate warranty cost on vehiclePrice
        /// </summary>
        /// <param name="vehiclePrice"></param>
        /// <returns>a double warranty calculated on the vehiclePrice</returns>
        private double calcVehicleWarranty(double vehiclePrice)
        {
            // Define local variable: double warranty
            double warranty = 0;

            // When the first item in the list is selected
            if (warrantyComboBox.SelectedIndex == 0)
            {
                // Calculate warranty based on warranty rate for 1 years
                warranty = vehiclePrice * WARRANTY_RATE_1;

            }
            // When the second item in the list is selected
            else if (warrantyComboBox.SelectedIndex == 1)
            {
                // Calculate warranty based on warranty rate for 2 years
                warranty = vehiclePrice * WARRANTY_RATE_2;
            }
            // When the third item in the list is selected
            else if (warrantyComboBox.SelectedIndex == 2)
            {
                // Calculate warranty based on warranty rate for 3 years
                warranty = vehiclePrice * WARRANTY_RATE_3;
            }
            // When the last item in the list is selected
            else
            {
                // Calculate warranty based on warranty rate for 5 years
                warranty = vehiclePrice * WARRANTY_RATE_5;
            }

            // return a double warranty
            return warranty;
        }

        /// <summary>
        /// calculate total cost of optional extras
        /// </summary>
        /// <returns>a double optionalExtras</returns>
        private double calcOptionalExtras()
        {
            // Define local variable: double optionalExtras
            double optionalExtras = 0;

            // if windowCheckBox is checked, add window tinting cost to optionalExtras
            if (windowCheckBox.IsChecked == true)
            {
                optionalExtras = optionalExtras + WINDOW_TINT;
            }

            // if ducoCheckBox is checked, add duco protection cost to optionalExtras
            if (ducoCheckBox.IsChecked == true)
            {
                optionalExtras = optionalExtras + DUCO_PROTECT;
            }

            // if floorCheckBox is checked, add floor mat cost to optionalExtras
            if (floorCheckBox.IsChecked == true)
            {
                optionalExtras = optionalExtras + FLOOR_MAT;
            }

            // if soundCheckBox is checked, add deluxes sound system cost to optionalExtras
            if (soundCheckBox.IsChecked == true)
            {
                optionalExtras = optionalExtras + DELUXE_SOUND;
            }

            // return a double optionalExtras
            return optionalExtras;
        }

        /// <summary>
        /// calculate insurance on vehiclePrice and optionalExtras
        /// </summary>
        /// <param name="vehiclePrice"></param>
        /// <param name="optionalExtras"></param>
        /// <returns>a double insurance calculated on the vehiclePrice and optionalExtras</returns>
        private double calcAccidentInsurance(double vehiclePrice, double optionalExtras)
        {
            // Define local variable: double insurance
            double insurance = 0;

            // if youngRadioButton is checked
            if (youngRadioButton.IsChecked == true)
            {
                // calculate insurance on vehiclePrice and optionalExtras and a insurance rate for younger group <25
                insurance = INSURANCE_YOUNG_RATE * (vehiclePrice + optionalExtras);
            }
            // else if oldRadioButton is checked
            else if (oldRadioButton.IsChecked == true)
            {
                // calculate insurance on vehiclePrice and optionalExtras and a insurance rate for older group >=25
                insurance = INSURANCE_OLD_RATE * (vehiclePrice + optionalExtras);
            }

            // return a double insurance
            return insurance;
        }


        /// <summary>
        /// Handles the switch toggle event for the insuranceToggleSwitch.
        /// disable and uncheck all radio buttons if the toggleSwitch is off.
        /// enable all radio buttons and check <25 radio button if the toggleSwitch is on.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void insuranceToggleSwitch_Toggled(object sender, RoutedEventArgs e)
        {
            // When the insurance toggleSwitch is off
            if (!insuranceToggleSwitch.IsOn)
            {
                // Disable the radio buttons
                youngRadioButton.IsEnabled = false;
                oldRadioButton.IsEnabled = false;

                // Uncheck the radio buttons
                youngRadioButton.IsChecked = false;
                oldRadioButton.IsChecked = false;
            }
            // When the insurance toggleSwitch is on
            else
            {
                // Enable the radio buttons
                youngRadioButton.IsEnabled = true;
                oldRadioButton.IsEnabled = true;

                // Set the under 25 radio button as default (checked)
                youngRadioButton.IsChecked = true;
            }
        }

        /// <summary>
        /// This method displays all items from customerName and customerPhone arrays
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void displayCustomerButton_Click(object sender, RoutedEventArgs e)
        {
            // Define initial empty string to contain array data
            string output = "";

            // loop through both array
            for (int index = 0; index < customerName.Length; index++)
            {
                // output concatenated string using each index of both arrays
                output = output + customerName[index] + ", " + customerPhone[index] + "\n";
            }

            // display all customer names and their corresponding phone numbers in the summaryTextBlock
            summaryTextBlock.Text = "All Customer names and Phone numbers:\n" + output;

        }

        /// <summary>
        /// This method takes a string item as parameter, performs a sequential search through the customerName array to find a match for the string item.
        /// it will return the index of the string item if found in the array
        /// or return a value of -1 if the string is not found
        /// </summary>
        /// <param name="criteria">The search criteria(string item) to match against the elements in the array.</param>
        /// <returns> The index value of the item if found, or -1 if not found </returns>
        private int searchArray(string criteria)
        {
            // to track position in array
            int counter = 0;
            // found will be true or false depending if name found
            bool found = false;

            // sequential search using while loop until match found or end of array reached
            while (!found && counter < customerName.Length)
            {
                // while not found and not end of array, check if the current name matches the search criteria
                if (criteria.ToUpper() == customerName[counter].ToUpper())
                {
                    // if name is found, found set true which will end while loop
                    found = true;
                }
                else
                {
                    // if no match, move to next element in array
                    counter++;
                }
            }

            // after found status determined or end of array reached:
            if (counter < customerName.Length)
            {
                // return the index of array element found
                return counter;
            }
            else
            {
                // return -1 if not found
                return -1;
            }
        }

        /// <summary>
        /// This method will: validate user input for searching criteria;
        /// display all name & phone data from arrays for reference;
        /// sequential search through customerName array to find a matching name;
        /// if found, display corresponding phone number of this customer;
        /// otherwise, output an error dialogue to user;
        /// </summary>
        /// <param name="sender">The event sender</param>
        /// <param name="e">The event arguments</param>
        private async void searchNameButton_Click(object sender, RoutedEventArgs e)
        {
            // to track position in array
            int counter = 0;

            // Validate that customerNameTextBox is not left blank
            if (string.IsNullOrWhiteSpace(customerNameTextBox.Text))
            {
                // if the customerNameTextBox is empty or whitespace-only, display an error message for user
                var invalidMessage = new MessageDialog("Please enter a customer name to search.");
                await invalidMessage.ShowAsync();
                // set focus to customerNameTextBox
                customerNameTextBox.Focus(FocusState.Programmatic);
                // return to caller
                return;
            }

            // get user input as the searching criteria
            string searchName = customerNameTextBox.Text;

            // call displayCustomerButton_Click method to display all name & phone data from arrays
            displayCustomerButton_Click(sender, e);

            // call sequential search method on searchName
            counter = searchArray(searchName);

            // use returned counter(index of the item) value to decide further actions
            if (counter == -1)
            {
                // if counter is -1 then the name is not found, output error dialogue
                var invalidMessage = new MessageDialog("The name " + searchName + " does not exist.");
                await invalidMessage.ShowAsync();
            }
            else
            {
                // else the name is found, display corresponding phone number in the phoneTextBox 
                phoneTextBox.Text = customerPhone[counter];                
            }

        }
      
        /// <summary>
        /// This method goes through sequential search to match user input name with the array
        /// if matches the name and its corresponding phone number will be deleted
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void deleteNameButton_Click(object sender, RoutedEventArgs e)
        {
            // to track position in array
            int counter = 0;
            // define a string variable to contain corresponding phone number
            string targetPhone = "";

            // Validate that customerNameTextBox is not left blank
            if (string.IsNullOrWhiteSpace(customerNameTextBox.Text))
            {
                // if the customerNameTextBox is empty or whitespace-only, display an error message for user
                var invalidMessage = new MessageDialog("Please enter a customer name to delete.");
                await invalidMessage.ShowAsync();
                // set focus to customerNameTextBox
                customerNameTextBox.Focus(FocusState.Programmatic);
                // return to caller
                return;
            }

            // get user input as the searching criteria
            string searchName = customerNameTextBox.Text;

            // call sequential search method on searchName
            counter = searchArray(searchName);

            // use returned counter(index of the item) value to decide further actions
            if (counter == -1)
            {
                // if counter is -1 then the name not found, output error dialogue
                var invalidMessage = new MessageDialog(searchName + " does not exist to delete.");
                await invalidMessage.ShowAsync();
            }
            else
            {
                // else a name has been found; set corresponding phone number to targetPhone
                targetPhone = customerPhone[counter];

                // enter for loop to replace the target item with item in their following index
                for (int i = counter; i < customerName.Length - 1; i++)
                {
                    // copy the next item in both array to the previous position
                    customerName[i] = customerName[i + 1];
                    customerPhone[i] = customerPhone[i + 1];
                }
                // resize both array by 1
                Array.Resize(ref customerName, customerName.Length - 1);
                Array.Resize(ref customerPhone, customerPhone.Length - 1);

                // Call displayCustomerButton_Click event to display updated Customer Name List
                displayCustomerButton_Click(sender, e);

                // Pop message to confirm deleted information
                var dialogMessage = new MessageDialog("Customer name: " + searchName + " Phone: " + targetPhone + " deleted, both array now updated to length " + customerName.Length);
                await dialogMessage.ShowAsync();
            }

        }

        /// <summary>
        /// This method displays all items in vehicleMakes array sorted in alphabetical order
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void displayMakeButton_Click(object sender, RoutedEventArgs e)
        {
            // sort the vehicleMakes array in alphabetical order
            Array.Sort(vehicleMakes);
            // Display the vehicleMakes array in the summaryTextBlock.
            summaryTextBlock.Text = string.Join("\n", vehicleMakes);
        }

        /// <summary>
        /// This method validates user input for searching criteria,
        /// displays sorted vehicle make data from arrays for reference,
        /// call method arrayStringBinarySearc to binary search through vehicleMakes array see if the input make exists,
        /// output error dialogue if the make not found in the list,
        /// ourput a message with its index to user if the make is found.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void searchMakeButton_Click(object sender, RoutedEventArgs e)
        {
            // Validate that vehicleMakeTextBox is not left blank
            if (string.IsNullOrWhiteSpace(vehicleMakeTextBox.Text))
            {
                // if the vehicleMakeTextBox is empty or whitespace-only, display an error message for user
                var invalidMessage = new MessageDialog("Please enter a vehicle make to search.");
                await invalidMessage.ShowAsync();
                // set focus to  vehicleMakeTextBox
                vehicleMakeTextBox.Focus(FocusState.Programmatic);
                // return to caller
                return;
            }

            // set user input as the searching criteria
            string criteria = vehicleMakeTextBox.Text;

            // make sure sort the vehicleMakes array in alphabetical order
            Array.Sort(vehicleMakes);

            // call the arrayBinarySearch method
            int foundPos = arrayStringBinarySearch(vehicleMakes, criteria);

            // use the value returned from arrayStringBinarySearch method into the if structure
            if (foundPos == -1)
            {
                // when returned value is -1 means target is not in the array, output dialogue not found
                var dialogMessage = new MessageDialog("Your search: " + criteria + " is not found.");
                await dialogMessage.ShowAsync();
            }
            else
            {
                // when returned value not -1 means target found in the array, output dialogue found and its index
                var dialogMessage = new MessageDialog("Your search: " + criteria + " is found at index " + foundPos);
                await dialogMessage.ShowAsync();

            }

            // call the previous method to display updated array sorted in alphabetical order
            displayMakeButton_Click(sender, e);
        }

        /// <summary>
        /// This method takes an string array and a string item as parameters
        /// This method performs a binary search on the string array to determine whether the given item exists
        /// it will return the index of the string item if found in the array
        /// or return a value of -1 if the string is not found
        /// </summary>
        /// <param name="data">The string array to search.</param>
        /// <param name="item">The string item to search for.</param>
        /// <returns> The index value of the item if found, or -1 if not found </returns>
        public int arrayStringBinarySearch(string[] data, string item)
        {
            // define integers to represent indexes in the array
            int min = 0;
            int max = data.Length - 1;
            int mid;

            // define local variable for string item taken from parameter
            item = item.ToUpper();

            // do...while loop to determine the position of the string item in the array
            do
            {
                mid = (min + max) / 2;

                // if the item is found return the index mid
                if (data[mid].ToUpper() == item)
                {
                    return mid;
                }

                // check if the item wanted is in the top half of the search 
                if (item.CompareTo(data[mid].ToUpper()) > 0)
                {
                    // if true set the min part of the search to the mid +1
                    min = mid + 1;
                }
                else
                {
                    // otherwise the item must be in the lower half of the search, set max to the mid-1
                    max = mid - 1;
                }

            } while (min <= max);

            // -1 is returned when the string item not found
            return -1;
        }

        /// <summary>
        /// This method perform binary search through arrayStringBinarySearc to match user input vehicleMake with array,
        /// once matched the input will be added to current array and displays in alphabetical order 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void insertMakeButton_Click(object sender, RoutedEventArgs e)
        {
            // Validate that vehicleMakeTextBox is not left blank
            if (string.IsNullOrWhiteSpace(vehicleMakeTextBox.Text))
            {
                // if the vehicleMakeTextBox is empty or whitespace-only, display an error message for user
                var invalidMessage = new MessageDialog("Please enter a vehicle make to insert.");
                await invalidMessage.ShowAsync();
                // set focus to vehicleMakeTextBox
                vehicleMakeTextBox.Focus(FocusState.Programmatic);
                // return to caller
                return;
            }

            // set user input in vehicleMakeTextBox as the searching criteria
            string insertMake = vehicleMakeTextBox.Text;

            // make sure sort the vehicleMakes array in alphabetical order
            Array.Sort(vehicleMakes);

            // call the arrayBinarySearch method to search against the input
            int foundPos = arrayStringBinarySearch(vehicleMakes, insertMake);

            if (foundPos != -1)
            {
                // if the item is found, display a message indicating user that the item already exists
                var invalidMessage = new MessageDialog("This vehicle make already exists at index " + foundPos.ToString() + " and don't need to be added again.");
                await invalidMessage.ShowAsync();
            }
            else
            {
                // if the item is not found, resize the array by 1
                Array.Resize(ref vehicleMakes, vehicleMakes.Length + 1);

                // assign the vehicle make entered to the last element in the array
                vehicleMakes[vehicleMakes.Length - 1] = insertMake;

            }

            // call the previous method to display updated array sorted in alphabetical order
            displayMakeButton_Click(sender, e);
        }

    }

}
